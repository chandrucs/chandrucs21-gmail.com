  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Copyright &copy; 28/05/2020
                    </div>
                    <div class="col-sm-6 text-right">
                        IoT Based Smart Toll Gate Using RFID
                    </div>
                </div>
            </div>
        </footer>