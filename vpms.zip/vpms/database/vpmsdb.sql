-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2020 at 07:12 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vpmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Admin', 'admin', 7898799798, 'tester1@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2019-07-05 05:38:23');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `ID` int(10) NOT NULL,
  `VehicleCat` varchar(120) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `tollfee` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`ID`, `VehicleCat`, `CreationDate`, `tollfee`) VALUES
(1, 'Four Wheeler Vehicle-light', '2019-07-05 11:06:50', 40),
(2, 'Two Wheeler Vehicle', '2019-07-05 11:07:09', 30),
(5, 'Four Wheeler Vehicle-medium', '2020-05-28 17:57:24', 60),
(6, 'Four Wheeler Vehicle-heavy', '2020-05-28 17:57:24', 80),
(7, 'Government Vehicle', '2020-05-28 17:58:37', 0),
(8, 'Eight Wheeler Vehicle', '2020-05-28 18:01:28', 101);

-- --------------------------------------------------------

--
-- Table structure for table `tbltransactionhistry`
--

CREATE TABLE `tbltransactionhistry` (
  `ID` int(11) NOT NULL,
  `TollBoothName` varchar(50) NOT NULL,
  `RFIDNumber` varchar(120) DEFAULT NULL,
  `VehicleCategory` varchar(120) NOT NULL,
  `VehicleCompanyname` varchar(120) DEFAULT NULL,
  `RegistrationNumber` varchar(120) DEFAULT NULL,
  `OwnerName` varchar(120) DEFAULT NULL,
  `OwnerContactNumber` bigint(10) DEFAULT NULL,
  `InTime` timestamp NULL DEFAULT NULL,
  `OutTime` timestamp NULL DEFAULT NULL,
  `TollCharge` varchar(120) NOT NULL,
  `Remark` mediumtext NOT NULL,
  `Status` varchar(5) NOT NULL,
  `accountnumber` int(11) NOT NULL,
  `bankname` varchar(50) NOT NULL,
  `ifsccode` varchar(12) NOT NULL,
  `balance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltransactionhistry`
--

INSERT INTO `tbltransactionhistry` (`ID`, `TollBoothName`, `RFIDNumber`, `VehicleCategory`, `VehicleCompanyname`, `RegistrationNumber`, `OwnerName`, `OwnerContactNumber`, `InTime`, `OutTime`, `TollCharge`, `Remark`, `Status`, `accountnumber`, `bankname`, `ifsccode`, `balance`) VALUES
(1, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-05-29 17:27:55', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 260),
(2, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-05-29 17:32:10', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 220),
(3, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-16 17:21:20', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 180),
(4, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-16 17:21:24', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 140),
(5, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-16 17:21:25', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 100),
(6, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-16 17:21:26', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 60),
(7, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-16 17:21:27', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 20),
(8, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-16 17:25:00', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 140),
(9, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-16 17:25:16', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 100),
(10, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-16 17:27:57', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 60),
(11, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-16 17:28:18', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 20),
(12, 'Managaluru-Bangaluru-Heavy-B14', '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-17 04:54:19', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 460);

-- --------------------------------------------------------

--
-- Table structure for table `tblvehicle`
--

CREATE TABLE `tblvehicle` (
  `ID` int(10) NOT NULL,
  `RFIDNumber` varchar(120) DEFAULT NULL,
  `VehicleCategory` varchar(120) NOT NULL,
  `VehicleCompanyname` varchar(120) DEFAULT NULL,
  `RegistrationNumber` varchar(120) DEFAULT NULL,
  `OwnerName` varchar(120) DEFAULT NULL,
  `OwnerContactNumber` bigint(10) DEFAULT NULL,
  `InTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `OutTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TollCharge` varchar(120) NOT NULL,
  `Remark` mediumtext NOT NULL,
  `Status` varchar(5) NOT NULL,
  `accountnumber` int(11) NOT NULL,
  `bankname` varchar(50) NOT NULL,
  `ifsccode` varchar(12) NOT NULL,
  `balance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblvehicle`
--

INSERT INTO `tblvehicle` (`ID`, `RFIDNumber`, `VehicleCategory`, `VehicleCompanyname`, `RegistrationNumber`, `OwnerName`, `OwnerContactNumber`, `InTime`, `OutTime`, `TollCharge`, `Remark`, `Status`, `accountnumber`, `bankname`, `ifsccode`, `balance`) VALUES
(25, '9744123', 'Four Wheeler Vehicle-light', 'Maruthi', 'KA17M1069', 'DeekshaKvayaPrajna', 9744484848, '2020-05-29 17:27:55', '2020-06-17 04:58:14', '40', 'paid', 'out', 2147483647, 'Vijaya Bank', '0001802', 460);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbltransactionhistry`
--
ALTER TABLE `tbltransactionhistry`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblvehicle`
--
ALTER TABLE `tblvehicle`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `accountnumber` (`accountnumber`),
  ADD UNIQUE KEY `RFIDNumber` (`RFIDNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbltransactionhistry`
--
ALTER TABLE `tbltransactionhistry`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `tblvehicle`
--
ALTER TABLE `tblvehicle`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
